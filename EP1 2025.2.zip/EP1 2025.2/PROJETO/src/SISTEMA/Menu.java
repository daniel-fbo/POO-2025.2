package SISTEMA;

public interface Menu {
     void abrirMenu();

}
