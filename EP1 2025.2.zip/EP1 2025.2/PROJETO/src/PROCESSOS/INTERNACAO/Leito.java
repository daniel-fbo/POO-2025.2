package PROCESSOS.INTERNACAO;
import ENTIDADES.PACIENTE.*;

public class Leito {
    private final short codigoLeito;
    private boolean ocupado;
    private final TipoLeito tipoLeito;
    private Paciente paciente;
    private double custoDiario;

    public Leito(short codigoLeito, TipoLeito tipoLeito, double custoDiario) {
        this.codigoLeito = codigoLeito;
        this.tipoLeito = tipoLeito;
        this.ocupado = false;
        this.paciente = null;
        this.custoDiario = custoDiario;
    }

    public int getCodigoLeito(){
        return codigoLeito;
    }
    public TipoLeito getTipoLeito() {
        return tipoLeito;
    }
    public boolean isOcupado(){
        return ocupado;
    }

    public void ocupar() {
        this.ocupado = true;
    }
    public void liberar() {
        this.ocupado = false;
    }

    @Override
    public String toString() {
        return "Leito: " + codigoLeito + " (" + tipoLeito + ") - " +
                (ocupado ? "Ocupado" : "Livre");
    }
}


}