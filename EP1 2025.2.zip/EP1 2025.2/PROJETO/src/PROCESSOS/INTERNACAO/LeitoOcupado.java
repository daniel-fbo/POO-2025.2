package PROCESSOS.INTERNACAO;

public class LeitoOcupado extends RuntimeException {
    public LeitoOcupado(String message) {
        super(message);
    }
}
