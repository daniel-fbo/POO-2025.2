package PROCESSOS.INTERNACAO;

public record RelatorioInternacao() {
}
