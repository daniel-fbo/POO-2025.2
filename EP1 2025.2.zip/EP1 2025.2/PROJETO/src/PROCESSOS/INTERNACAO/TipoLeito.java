package PROCESSOS.INTERNACAO;

public enum TipoLeito {
    SALA_VERMELHA,
    SALA_AMARELA,
    QUARTO,
}
