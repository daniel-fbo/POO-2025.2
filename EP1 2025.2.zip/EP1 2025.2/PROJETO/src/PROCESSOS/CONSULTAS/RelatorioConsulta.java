package PROCESSOS.CONSULTAS;

public record RelatorioConsulta() {
}
