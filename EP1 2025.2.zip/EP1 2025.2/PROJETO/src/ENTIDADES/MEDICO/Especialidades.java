package ENTIDADES.MEDICO;

public enum Especialidades {
    Cardiologia,
    Cirurgia,
    Endocrinologia,
    Oncologia,
    Oftalmologia,
    Pediatra,
    Psiquiatria
}
