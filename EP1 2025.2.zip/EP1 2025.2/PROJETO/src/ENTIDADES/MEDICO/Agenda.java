package ENTIDADES.MEDICO;

public class Agenda {

}
