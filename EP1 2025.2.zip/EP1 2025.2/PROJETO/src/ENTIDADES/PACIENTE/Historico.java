package ENTIDADES.PACIENTE;

public class Historico {

}
