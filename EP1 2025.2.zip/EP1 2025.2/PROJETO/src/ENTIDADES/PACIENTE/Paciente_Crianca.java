package ENTIDADES.PACIENTE;

public class Paciente_Crianca extends Paciente {
    public Paciente_Crianca(String nome, String cpf, short idade, EstadoPaciente estado){
    super(nome,cpf,idade,estado);
}
}
