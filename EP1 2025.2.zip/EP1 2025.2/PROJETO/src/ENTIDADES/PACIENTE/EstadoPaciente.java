package ENTIDADES.PACIENTE;

public enum EstadoPaciente {
    Azul,
    Verde,
    Amarelo,
    Vermelho,
}
